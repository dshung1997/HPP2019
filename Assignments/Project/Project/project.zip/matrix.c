#include "matrix.h"

matrix* matrix_addition(matrix* a, matrix* b)
{
    matrix* c = (matri)
}

matrix* matrix_multiplication(matrix* a, matrix* b);