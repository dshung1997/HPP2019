#include <stdio.h>
#include <math.h>
#include <stdlib.h>
#include "./graphics/graphics.h"
#include <string.h>
#include <sys/time.h>

static double get_wall_seconds() {
  struct timeval tv;
  gettimeofday(&tv, NULL);
  double seconds = tv.tv_sec + (double)tv.tv_usec / 1000000;
  return seconds;
}

int main(int argc, char **argv)
{
  if (argc != 6) {
    printf("Invalid inputs!\nInstruction: ./galsim N filename nsteps delta_t graphics\n");
    return 0;
  }
  double time1;
  time1 = get_wall_seconds();
  const unsigned int N = atoi(argv[1]);
  const char* filename = argv[2];
  const unsigned int nsteps = atoi(argv[3]);
  const double delta_t = atof(argv[4]);
  const char graphics = atoi(argv[5]);

  FILE* fp = fopen(filename, "r");
  if (fp == NULL) {
    printf("Invalid input file: %s\n. Exit.", filename);
    return 0;
  }
  double* mass = (double*) malloc(sizeof(double)*N);
  double* brightness = (double*) malloc(sizeof(double)*N);
  double* x = (double*) malloc(sizeof(double)*N);
  double* y = (double*) malloc(sizeof(double)*N);
  double* ux = (double*) malloc(sizeof(double)*N);
  double* uy = (double*) malloc(sizeof(double)*N);
  unsigned int i;
  double buff;
  for (i =0; i < N; i++)
  {
    fread(&buff, sizeof(double), 1, fp);
    x[i] = buff;
    fread(&buff, sizeof(double), 1, fp);
    y[i] = buff;
    fread(&buff, sizeof(double), 1, fp);
    mass[i] = buff;
    fread(&buff, sizeof(double), 1, fp);
    ux[i] = buff;
    fread(&buff, sizeof(double), 1, fp);
    uy[i] = buff;
    fread(&buff, sizeof(double), 1, fp);
    brightness[i] = buff;
  }
  fclose(fp);
  printf("Reading input file took %7.7f wall seconds\n", get_wall_seconds() - time1);
  if (graphics) {
    InitializeGraphics(argv[0], 800, 800);
    SetCAxes(0, 1);
  }
  time1 = get_wall_seconds();
  unsigned int j, k;
  const double G = 100.0/(double)N;
  const double e0 = 0.001;
  double* sumx = (double*) malloc(sizeof(double)*N);
  double* sumy = (double*) malloc(sizeof(double)*N);
  for (k = 0; k < nsteps; k++) {
    if (graphics) {
      ClearScreen();
    }
    //double sumx[N];
    //double sumy[N];
    memset(sumx, 0, N*sizeof(double));
    memset(sumy, 0, N*sizeof(double));
    for (i = 0; i < N; i++) {
      if (graphics) {
        DrawCircle(x[i], y[i], 1, 1, 0.005, 0);
      }
      for (j = 0; j < i; j++) {
	double delta_x = x[i]-x[j];
        double delta_y = y[i]-y[j];
        double rij_e0 = sqrt(delta_x*delta_x+delta_y*delta_y)+e0;
        double temp = 1/(rij_e0*rij_e0*rij_e0);
        sumx[i] += mass[j]*temp*delta_x;
        sumy[i] += mass[j]*temp*delta_y;
        sumx[j] += -mass[i]*temp*delta_x;
        sumy[j] += -mass[i]*temp*delta_y;
      }
    }
    for (i = 0; i < N; i++) {
      ux[i] = ux[i] -G*delta_t*sumx[i];
      uy[i] = uy[i] -G*delta_t*sumy[i];
      x[i] = x[i] + delta_t*ux[i];
      y[i] = y[i] + delta_t*uy[i];
    }
    if (graphics) {
      Refresh();
      usleep(5000);
    }
  }
  free(sumx); free(sumy);
  printf("Calculations took %7.7f wall seconds\n", get_wall_seconds() - time1);
  if (graphics) {
    FlushDisplay();
    CloseDisplay();
  }
  time1 = get_wall_seconds();
  fp = fopen("result.gal", "w");
  for (i = 0; i < N; i++)
  {
    fwrite(&(x[i]), 1, sizeof(double), fp);
    fwrite(&(y[i]), 1, sizeof(double), fp);
    fwrite(&(mass[i]), 1, sizeof(double), fp);
    fwrite(&(ux[i]), 1, sizeof(double), fp);
    fwrite(&(uy[i]), 1, sizeof(double), fp);
    fwrite(&(brightness[i]), 1, sizeof(double), fp);
  }
  fclose(fp);
  free(x); free(y); free(ux); free(uy); free(mass); free(brightness);
  printf("Writing output file took %7.7f wall seconds\n", get_wall_seconds() - time1);
  return 0;
}
