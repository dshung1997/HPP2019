echo Hej hej
echo Marius
echo Hi teacher