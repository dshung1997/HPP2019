#define G 71

void print_pyramid(int pyramidSize);
