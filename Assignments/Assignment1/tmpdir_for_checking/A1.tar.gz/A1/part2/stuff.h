#define G 333

void print_pyramid(int pyramidSize);
