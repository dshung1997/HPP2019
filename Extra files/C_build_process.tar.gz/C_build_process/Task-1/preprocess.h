// Preprocess.h includes the function definition of the add() function
// Are comments also included by the preprocessor?

#ifndef PREPROCESS_H
#define PREPROCESS_H

int add(int, int);

void function_we_dont_use();

#endif 
