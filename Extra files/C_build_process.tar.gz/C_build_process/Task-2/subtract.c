/* --- source file : subtract.c ---*/ 


int subtract(int num1 , int num2)
    {
        return (num1-num2);
    }
