
void transform_opt (float * dest, 
		    const float * src, 
		    const float * params, 
		    int n);

