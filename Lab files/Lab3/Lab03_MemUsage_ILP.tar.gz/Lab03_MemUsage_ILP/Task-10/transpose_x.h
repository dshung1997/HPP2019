void do_transpose_x_standard (double** B, int nB, const double* A, int N);
void do_transpose_x_optimized(double** B, int nB, const double* A, int N);
